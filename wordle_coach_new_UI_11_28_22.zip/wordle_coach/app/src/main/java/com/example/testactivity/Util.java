package com.example.testactivity;

public interface Util {
    final public String YELLOW_HEX = "#FFA500";
    final public String GRAY_HEX = "#D3D3D3";
    final public String GREEN_HEX = "#2F8E3C";
}
