package com.example.testactivity;

public class ColorToggleButtons extends MainActivity {
    public int toggle1, toggle2, toggle3, toggle4, toggle5; // these are button toggles for changing button colors
}
